# Documentation

All open api components are in Error.php file (responses and responses errors schemas) : [Error]("../http/Error.php")

All endpoints description are in the Endpoint.php file : [Endpoint]("../Core/Endpoint.php")
