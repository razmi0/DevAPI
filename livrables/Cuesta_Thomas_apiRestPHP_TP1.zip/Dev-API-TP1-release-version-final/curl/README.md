# Curl

Run them all :

```bash
composer run-script curl:run
```

## Curl class

Very simple class, it provides a simple interface to make curl requests.

## Test class

Assert a condition and emit terminal formated messages.
