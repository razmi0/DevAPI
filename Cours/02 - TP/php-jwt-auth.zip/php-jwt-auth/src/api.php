<?php
use Firebase\JWT\JWT;
use Firebase\JWT\Key;
class api
{
    // Votre clé secrète
    private $secretKey = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwOlwvXC8xMjcuMC4wLjFcL3BocC1qd3QtYXV0aCIsImF1ZCI6Imh0dHA6XC9cLzEyNy4wLjAuMVwvcGhwLWp3dC1hdXRoIiwiaWF0IjoxNzI4NzQ1NDU1LCJuYmYiOjE3Mjg3NDU0NTUsInVzZXJuYW1lIjoidGVzdF91c2VyIn0.0wbsZ-Ava6PYLXmKndwDyYyOv8vqd_1uZH6EpxnQ2Uk'; 
    
    // Traitement de la méthode POST
    public function handlePostRequest()
    {
        // on récupére les données transmises
        $input = json_decode(file_get_contents('php://input'), true);
        // SI username et password sont présents
        if (isset($input['username']) && isset($input['password'])) {
            // On génère le token
            $token = $this->generateToken($input['username']);
            echo json_encode(['token' => $token]);
        } else {
            header("HTTP/1.1 400 Bad Request");
            echo json_encode(['message' => 'Invalid input']);
        }
    }

    // Traitement de la méthode GET
    public function handleGetRequest()
    {
        // On récupère les headers transmis de le requête corurante
        $headers = apache_request_headers();
        // SI le header contient la clé Authorization
        if (isset($headers['Authorization'])) {
            // On récupère le contenu de la clé
            $authHeader = $headers['Authorization'];
            list($jwt) = sscanf($authHeader, 'Bearer %s');
            if ($jwt) {
                try {
                    // On décode le token : lève une exception si le token est
                    // invalide
                    // Retourne le payload du token comme un objet PHP
                    $decoded = JWT::decode($jwt, new Key($this->secretKey, 'HS256'));
                    // Retourner un message
                    echo json_encode(['message' => 'Accès autorisé', 'user' => $decoded->username]);
                } catch (Exception $e) {
                    header("HTTP/1.1 401 Unauthorized");
                    echo json_encode(['message' => 'Accès NON autorisé', 'error' => $e->getMessage()]);
                }
            } else {
                header("HTTP/1.1 400 Bad Request");
                echo json_encode(['message' => 'Format du token invalide']);
            }
        } else {
            header("HTTP/1.1 400 Bad Request");
            echo json_encode(['message' => 'Authorization header non trouvé']);
        }
    }

    // Générer le token
    private function generateToken($username)
    {
        $payload = [
            // permet d’identifier l’émetteur du token 
            'iss' => "http://127.0.0.1/php-jwt-auth",
            // aud identifie le public du jeton, c'est-à-dire qui devrait le consommer
            'aud' => "http://127.0.0.1/php-jwt-auth",
            // stands for issued at : l'heure à laquelle le JWT a été émis.
            'iat' => time(),
            // Not before
            // 'nbf' => time(),
            // exp  indique la date d’expiration du token. 
            // Si la date d’expiration est dépassée, le token sera rejeté.
            'exp' => time()+600,
            'username' => $username
        ];

        // Générer le token à partir du payload et de la clé secrete
        // Le token est encrypté en HS256
        return JWT::encode($payload, $this->secretKey, 'HS256');
    }
}