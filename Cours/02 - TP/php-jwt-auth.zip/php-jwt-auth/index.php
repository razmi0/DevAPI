<?php
// include the composer installed packages
require './vendor/autoload.php';
require './src/api.php';

header("Content-Type: application/json; charset=UTF-8");
// On parse l'URI reçue
$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
// Création d'un tableau
$uri = explode('/', $uri);

// SI api n'est pas dans l'URI, on retourne un message et on quitte le script
if ($uri[2] !== 'api') {
    header("HTTP/1.1 404 Not Found");
    exit();
}

// On récupère la méthode utilisée
$method = $_SERVER['REQUEST_METHOD'];

// Instanciation de la classe api
$api = new api();

switch ($method) {
    case 'POST':
        // Appel de la méthode handlePostRequest() de la classe api
        $api->handlePostRequest();
        break;
    case 'GET':
        // Appel de la méthode handleGetRequest() de la classe api
        $api->handleGetRequest();
        break;
    default:
        header("HTTP/1.1 405 Method Not Allowed");
        exit();
}